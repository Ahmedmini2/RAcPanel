<?php 
session_unset();

session_destroy();
echo "done";


?>